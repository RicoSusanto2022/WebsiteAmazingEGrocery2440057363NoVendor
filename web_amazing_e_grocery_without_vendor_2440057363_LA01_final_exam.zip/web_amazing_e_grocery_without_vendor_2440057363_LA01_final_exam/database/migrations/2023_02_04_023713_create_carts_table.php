<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCartsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('carts', function (Blueprint $table) {
            $table->id("cart_id");
            $table->foreignId("account_id")->constrained("users", "id")->onDelete("cascade")->onUpdate("cascade");
            $table->foreignId("item_id")->constrained("items","item_id")->onDelete("cascade")->onUpdate("cascade");
            $table->integer("price");
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('carts');
    }
}
