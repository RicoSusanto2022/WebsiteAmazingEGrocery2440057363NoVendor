<footer class="shadow-lg custom-bg-green d-flex py-4">
    <div class="fs-5 text-light fw-bold w-50 d-flex align-items-center justify-content-center border-end border-3 border-white">
        © Amazing E-Grocery 2023
    </div>
    <div class="w-50 ms-2">
        <div class="text-light fw-semibold">
            <?php echo e(__("translate.footer.find")); ?> | <?php echo e(__("translate.footer.decide")); ?> | <?php echo e(__("translate.footer.order")); ?>

        </div>
        <div class="text-light pe-2 mt-2">
            <?php echo e(__("translate.footer.desc")); ?>

        </div>
    </div>
</footer><?php /**PATH C:\BINUS5\UJIAN_AKHIR_SEMESTER_5\WebProgggg\JAWABAN\web_amazing_e_grocery\resources\views/footer.blade.php ENDPATH**/ ?>