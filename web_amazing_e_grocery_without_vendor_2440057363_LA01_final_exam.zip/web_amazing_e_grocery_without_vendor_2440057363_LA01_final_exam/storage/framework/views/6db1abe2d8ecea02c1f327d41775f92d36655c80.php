
<?php $__env->startSection('web_content'); ?>
<div class="dflt-h d-flex flex-column justify-content-center align-items-center">
    <div class="text-center d-flex">
        <h1 class="fw-bold custom-txt-green title-r"><?php echo e(__("translate.index.title")); ?></h1> 
    </div>
    <div class="bar-mov rounded"></div>
    <div class="mt-3 fw-semibold">
        <?php echo e(__("translate.index.create")); ?>

    </div>
    <div class="mt-2 w-50 text-center">
        <?php echo e(__("translate.index.desc")); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\BINUS5\UJIAN_AKHIR_SEMESTER_5\WebProgggg\JAWABAN\web_amazing_e_grocery\resources\views/index.blade.php ENDPATH**/ ?>